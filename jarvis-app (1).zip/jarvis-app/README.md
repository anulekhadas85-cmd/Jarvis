# Jarvis — ভয়েস দিয়ে ফোন চালানোর অ্যাপ

"Jarvis" বললে অ্যাপ জেগে ওঠে, আপনার কথা শোনে, Gemini-কে স্ক্রিন দেখিয়ে সিদ্ধান্ত নেয়, তারপর নিজে ট্যাপ/স্ক্রল/টাইপ করে কাজ শেষ করে।

## ১. দুটো key জোগাড় করুন (ফ্রি)
- **Gemini API key:** https://aistudio.google.com/apikey
- **Picovoice AccessKey:** https://console.picovoice.ai (সাইন আপ করলেই পাবেন; এটা "Jarvis" wake word চেনার জন্য)

## ২. APK বানান (যেকোনো একটা উপায়)

**ক) Android Studio (কম্পিউটারে):**
1. Android Studio খুলে `File > Open` দিয়ে এই ফোল্ডারটা খুলুন।
2. Sync শেষ হলে `Build > Build APK(s)`।
3. APK পাবেন `app/build/outputs/apk/debug/app-debug.apk`-এ।
(Gradle নিয়ে সমস্যা হলে Settings-এ Gradle 8.7 আর JDK 17 বেছে নিন।)

**খ) GitHub দিয়ে (কম্পিউটার ছাড়া):**
1. GitHub-এ নতুন repository বানিয়ে এই ফোল্ডারের সব ফাইল আপলোড করুন (`.github` ফোল্ডারসহ)।
2. repository-র `Actions` ট্যাবে `Build APK` চলবে।
3. শেষ হলে সেই run খুলে নিচে `jarvis-apk` ডাউনলোড করুন।

## ৩. ফোনে চালু করার ধাপ
1. APK ইনস্টল করুন (Unknown apps ইনস্টলের অনুমতি দিতে হতে পারে)।
2. অ্যাপ খুলে দুটো key বসিয়ে **সেভ করুন** চাপুন।
3. **Accessibility চালু করুন** চাপুন → "Jarvis" খুঁজে চালু করুন।
   - Android 13+ এ বাধা দিলে: ফোনের `Settings > Apps > Jarvis` → উপরের ডানে ⋮ → **Allow restricted settings**, তারপর আবার চেষ্টা করুন।
4. **ব্যাটারি সীমা বন্ধ করুন** চেপে Jarvis-কে "Unrestricted" / "Don't optimize" করুন। Xiaomi, Realme, Vivo, Oppo, Samsung-এ আলাদা "Autostart" বা "Background activity" সেটিংও চালু করতে হয়।
5. **Jarvis চালু করুন** চাপুন, মাইক ও কলের অনুমতি দিন।
6. এবার বলুন: **"Jarvis"** → "জি, বলুন" শুনলে কাজ বলুন।

## উদাহরণ
- "YouTube খুলে লোফি গান চালাও"
- "ওয়াটসঅ্যাপে রিয়াকে লেখো আমি আসছি" (পাঠানোর আগে জিজ্ঞেস করবে)
- "নিচে স্ক্রল করো", "এখানে ট্যাপ করো", "পেছনে যাও"

## সীমা ও নিরাপত্তা
- জরুরি কাজ (কল, মেসেজ পাঠানো, পেমেন্ট, ডিলিট) করার আগে Jarvis নিজেই জিজ্ঞেস করে। পাসওয়ার্ড ও OTP সে লেখে না।
- ব্যাংকিং অ্যাপ ও পাসওয়ার্ড ঘর Android নিজেই Accessibility থেকে আড়াল করে, সেখানে কাজ হবে না।
- wake word এখন "Jarvis"। "Hey Jarvis" চাইলে Picovoice Console-এ কাস্টম keyword ট্রেন করে `.ppn` ফাইল নিয়ে `JarvisService.kt`-এ `setKeywordPath` ব্যবহার করতে হবে।
- আপনার কথা Google-এর speech service আর স্ক্রিনের লেখা Gemini-তে যায়, তাই ব্যক্তিগত স্ক্রিনে সাবধান।
- এটা নিজের ফোনে ব্যবহারের জন্য। Play Store-এর Accessibility নীতিতে এই ধরনের অ্যাপ কঠিন।
