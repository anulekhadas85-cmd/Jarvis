package com.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * The "brain loop": sends the command + current screen to Gemini, runs the actions it returns,
 * looks at the new screen, and repeats until the task is done.
 */
class Agent(
    private val ctx: Context,
    private val speak: suspend (String) -> Unit,
    private val listen: suspend () -> String?
) {

    companion object {
        private const val SYSTEM = """
You are Jarvis, a voice assistant that controls an Android phone for its owner.
Each turn you get the user's command, the list of installed apps, and the current screen as a numbered list of UI elements.

Reply ONLY with JSON: {"say":"","actions":[],"ask":"","done":false}
- say: a short sentence to speak aloud, in the same language the user spoke (Bangla in Bangla script). Empty if nothing to say.
- actions: ordered list. Allowed types:
  {"type":"open_app","name":"<app label exactly as in the installed list>"}
  {"type":"tap_id","id":N}   (N is the [number] from the SCREEN list)
  {"type":"tap_text","text":"..."}
  {"type":"tap_xy","x":N,"y":N}
  {"type":"type","text":"..."}   (types into the focused or first editable field)
  {"type":"enter"}
  {"type":"scroll","direction":"up|down|left|right"}
  {"type":"back"} {"type":"home"} {"type":"recents"} {"type":"notifications"}
  {"type":"open_url","url":"..."}
  {"type":"call","number":"..."}
  {"type":"sms","number":"...","body":"..."}
  {"type":"wait","ms":1000}
- ask: a question for the user (to confirm something or get missing info). If non-empty, the user's spoken answer comes next.
- done: true when the task is finished or impossible. false if you need to see the new screen after your actions.

Rules:
- Use element ids only from the most recent SCREEN. Do a few actions per turn, then look again.
- ALWAYS ask for confirmation before: placing a call, sending any message or email, any payment or purchase, deleting data, posting publicly.
- Never read out or type passwords, OTPs, PINs or card numbers. If a task needs them, ask the user to do that step themselves.
- If you cannot do something, say so briefly and set done=true.
- Keep spoken sentences short.
"""
    }

    suspend fun run(command: String) {
        val svc = JarvisAccessibilityService.instance
        if (svc == null) {
            speak("Accessibility চালু নেই। অ্যাপ খুলে সেটা চালু করুন।")
            return
        }
        val key = Prefs.get(ctx, Prefs.GEMINI)
        if (key.isBlank()) {
            speak("Gemini key দেওয়া হয়নি।")
            return
        }
        val gemini = GeminiClient(key, Prefs.get(ctx, Prefs.MODEL, "gemini-2.5-flash"))
        val history = JSONArray()

        fun turn(role: String, text: String) {
            history.put(
                JSONObject().put("role", role)
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }

        val apps = svc.appLabels().joinToString(", ")
        turn("user", "COMMAND: $command\nINSTALLED APPS: $apps\nSCREEN:\n${svc.dumpScreen()}")

        for (step in 0 until 12) {
            val raw = withContext(Dispatchers.IO) { gemini.generate(SYSTEM, history) }
            turn("model", raw)

            val reply = try {
                JSONObject(raw)
            } catch (e: Exception) {
                speak("উত্তরটা বুঝতে পারিনি।")
                return
            }

            val say = reply.optString("say")
            if (say.isNotBlank()) speak(say)

            val results = StringBuilder()
            val actions = reply.optJSONArray("actions")
            if (actions != null) {
                for (i in 0 until actions.length()) {
                    results.append(exec(actions.getJSONObject(i), svc)).append('\n')
                    delay(400)
                }
            }

            val ask = reply.optString("ask")
            if (ask.isNotBlank()) {
                speak(ask)
                val answer = listen()
                if (answer.isNullOrBlank()) {
                    speak("উত্তর শুনতে পাইনি, কাজটা বাদ দিলাম।")
                    return
                }
                delay(600)
                turn("user", "USER ANSWER: $answer\nACTION RESULTS:\n$results\nSCREEN:\n${svc.dumpScreen()}")
                continue
            }

            if (reply.optBoolean("done", true)) return

            delay(900) // let the screen settle
            turn("user", "ACTION RESULTS:\n$results\nSCREEN:\n${svc.dumpScreen()}")
        }
        speak("অনেকক্ষণ চেষ্টা করলাম, শেষ করতে পারিনি।")
    }

    private suspend fun exec(a: JSONObject, s: JarvisAccessibilityService): String {
        val type = a.optString("type")
        val ok = when (type) {
            "open_app" -> s.openApp(a.optString("name"))
            "tap_id" -> s.tapId(a.optInt("id", -1))
            "tap_text" -> s.tapText(a.optString("text"))
            "tap_xy" -> s.tapXY(a.optInt("x"), a.optInt("y"))
            "type" -> s.typeText(a.optString("text"))
            "enter" -> s.pressEnter()
            "scroll" -> s.scroll(a.optString("direction", "down"))
            "back" -> s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            "home" -> s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            "recents" -> s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
            "notifications" -> s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            "open_url" -> s.openUrl(a.optString("url"))
            "call" -> s.call(a.optString("number"))
            "sms" -> s.sms(a.optString("number"), a.optString("body"))
            "wait" -> {
                delay(a.optLong("ms", 1000).coerceIn(0, 5000))
                true
            }
            else -> false
        }
        return "$type: ${if (ok) "ok" else "failed"}"
    }
}
