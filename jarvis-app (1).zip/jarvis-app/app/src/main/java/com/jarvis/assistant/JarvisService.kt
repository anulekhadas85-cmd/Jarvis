package com.jarvis.assistant

import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineManager
import ai.picovoice.porcupine.PorcupineManagerCallback
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

/**
 * Always-on foreground service: waits for "Jarvis", listens to the command, runs the Agent.
 */
class JarvisService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var porcupine: PorcupineManager? = null
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val pending = ConcurrentHashMap<String, () -> Unit>()

    @Volatile
    private var busy = false

    private fun lang() = Prefs.get(this, Prefs.LANG, "bn-IN")

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()

        val channel = NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        val notification = NotificationCompat.Builder(this, "jarvis")
            .setContentTitle("Jarvis")
            .setContentText("\"Jarvis\" বললেই আমি জেগে উঠব")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(this, 1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.language = Locale.forLanguageTag(lang())
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        utteranceId?.let { pending.remove(it)?.invoke() }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        utteranceId?.let { pending.remove(it)?.invoke() }
                    }
                })
            }
        }

        startWakeWord()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onDestroy() {
        try {
            porcupine?.stop()
            porcupine?.delete()
        } catch (_: Exception) {
        }
        recognizer?.destroy()
        tts?.shutdown()
        scope.cancel()
        super.onDestroy()
    }

    // ---------- Wake word ----------

    private fun startWakeWord() {
        val key = Prefs.get(this, Prefs.PICO)
        if (key.isBlank()) {
            speak("Picovoice key দেওয়া হয়নি।") {}
            return
        }
        try {
            porcupine = PorcupineManager.Builder()
                .setAccessKey(key)
                .setKeyword(Porcupine.BuiltInKeyword.JARVIS)
                .build(this, PorcupineManagerCallback { main.post { onWake() } })
            porcupine?.start()
        } catch (e: Exception) {
            speak("Wake word চালু হয়নি। Picovoice key ঠিক আছে কিনা দেখুন।") {}
        }
    }

    private fun onWake() {
        if (busy) return
        busy = true
        try {
            porcupine?.stop() // release the microphone for speech recognition
        } catch (_: Exception) {
        }
        scope.launch {
            try {
                speakS("জি, বলুন")
                val command = listenS()
                if (command.isNullOrBlank()) {
                    speakS("কিছু শুনতে পাইনি")
                } else {
                    Agent(applicationContext, { speakS(it) }, { listenS() }).run(command)
                }
            } catch (e: Exception) {
                speakS("সমস্যা হয়েছে। ${e.message?.take(80).orEmpty()}")
            } finally {
                busy = false
                main.post {
                    try {
                        porcupine?.start()
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }

    // ---------- Speech output ----------

    private fun speak(text: String, done: () -> Unit) {
        val t = tts
        if (t == null || !ttsReady || text.isBlank()) {
            done()
            return
        }
        val id = UUID.randomUUID().toString()
        pending[id] = done
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    private suspend fun speakS(text: String) = suspendCoroutine<Unit> { c ->
        speak(text) { c.resume(Unit) }
    }

    // ---------- Speech input ----------

    private fun listen(onceCallback: (String?) -> Unit) {
        val fired = java.util.concurrent.atomic.AtomicBoolean(false)
        val callback: (String?) -> Unit = { if (fired.compareAndSet(false, true)) onceCallback(it) }
        main.post {
            recognizer?.destroy()
            val r = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer = r
            r.setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    callback(
                        results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    )
                }

                override fun onError(error: Int) = callback(null)
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang())
            r.startListening(intent)
        }
    }

    private suspend fun listenS() = suspendCoroutine<String?> { c ->
        listen { c.resume(it) }
    }
}
