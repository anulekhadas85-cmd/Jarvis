package com.jarvis.assistant

import android.content.Context

object Prefs {
    const val GEMINI = "gemini_key"
    const val PICO = "pico_key"
    const val LANG = "lang"
    const val MODEL = "model"

    private fun sp(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    fun get(c: Context, key: String, default: String = ""): String =
        sp(c).getString(key, default)?.takeIf { it.isNotBlank() } ?: default

    fun put(c: Context, key: String, value: String) {
        sp(c).edit().putString(key, value.trim()).apply()
    }
}
