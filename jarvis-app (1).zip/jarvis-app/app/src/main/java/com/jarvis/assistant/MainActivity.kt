package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var geminiKey: EditText
    private lateinit var picoKey: EditText
    private lateinit var lang: EditText
    private lateinit var model: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        fun label(t: String) = TextView(this).apply {
            text = t
            setPadding(0, pad / 2, 0, 0)
        }

        fun field(hint: String, key: String, default: String = "") = EditText(this).apply {
            this.hint = hint
            setText(Prefs.get(this@MainActivity, key, default))
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT
        }

        fun button(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t
            setOnClickListener { onClick() }
        }

        col.addView(TextView(this).apply {
            text = "Jarvis"
            textSize = 28f
        })
        status = TextView(this)
        col.addView(status)

        col.addView(label("Gemini API key (aistudio.google.com/apikey)"))
        geminiKey = field("AIza...", Prefs.GEMINI); col.addView(geminiKey)

        col.addView(label("Picovoice AccessKey (console.picovoice.ai)"))
        picoKey = field("AccessKey", Prefs.PICO); col.addView(picoKey)

        col.addView(label("ভাষা (bn-IN বাংলা, en-IN ইংরেজি, hi-IN হিন্দি)"))
        lang = field("bn-IN", Prefs.LANG, "bn-IN"); col.addView(lang)

        col.addView(label("Gemini মডেল"))
        model = field("gemini-2.5-flash", Prefs.MODEL, "gemini-2.5-flash"); col.addView(model)

        col.addView(button("সেভ করুন") { save(); toast("সেভ হয়েছে") })
        col.addView(button("১. Accessibility চালু করুন") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(button("২. ব্যাটারি সীমা বন্ধ করুন") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        col.addView(button("৩. Jarvis চালু করুন") { startJarvis() })
        col.addView(button("Jarvis বন্ধ করুন") {
            stopService(Intent(this, JarvisService::class.java))
            toast("বন্ধ করা হয়েছে")
        })

        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        val acc = if (JarvisAccessibilityService.instance != null) "চালু" else "বন্ধ"
        val mic = if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) "আছে" else "নেই"
        status.text = "Accessibility: $acc   |   মাইক অনুমতি: $mic"
    }

    private fun save() {
        Prefs.put(this, Prefs.GEMINI, geminiKey.text.toString())
        Prefs.put(this, Prefs.PICO, picoKey.text.toString())
        Prefs.put(this, Prefs.LANG, lang.text.toString())
        Prefs.put(this, Prefs.MODEL, model.text.toString())
    }

    private fun startJarvis() {
        save()
        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE)
        if (Build.VERSION.SDK_INT >= 33) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = needed.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), 1)
        } else {
            launchService()
        }
    }

    override fun onRequestPermissionsResult(code: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, permissions, results)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            launchService()
        } else {
            toast("মাইকের অনুমতি ছাড়া Jarvis কাজ করবে না")
        }
    }

    private fun launchService() {
        startForegroundService(Intent(this, JarvisService::class.java))
        toast("Jarvis চালু। এখন \"Jarvis\" বলুন")
        onResume()
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()
}
