package com.jarvis.assistant

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Path
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * The "hands" of Jarvis: reads the screen and performs taps, swipes, typing and app launches.
 */
class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: JarvisAccessibilityService? = null
    }

    @Volatile
    private var nodes: List<AccessibilityNodeInfo> = emptyList()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // ---------- Reading the screen ----------

    fun dumpScreen(): String {
        val root = rootInActiveWindow ?: return "(screen not readable)"
        val list = mutableListOf<AccessibilityNodeInfo>()
        val sb = StringBuilder()
        val dm = resources.displayMetrics
        sb.append("screen=${dm.widthPixels}x${dm.heightPixels} app=${root.packageName}\n")

        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || list.size >= 150) return
            if (n.isVisibleToUser) {
                val text = if (n.isPassword) "<password>" else n.text?.toString()?.take(80).orEmpty()
                val desc = n.contentDescription?.toString()?.take(80).orEmpty()
                if (text.isNotEmpty() || desc.isNotEmpty() || n.isClickable || n.isEditable) {
                    val r = Rect()
                    n.getBoundsInScreen(r)
                    sb.append("[${list.size}] ")
                    if (text.isNotEmpty()) sb.append("text=\"$text\" ")
                    if (desc.isNotEmpty()) sb.append("desc=\"$desc\" ")
                    if (n.isClickable) sb.append("clickable ")
                    if (n.isEditable) sb.append("editable ")
                    sb.append("bounds=${r.left},${r.top},${r.right},${r.bottom}\n")
                    list.add(n)
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        nodes = list
        return sb.toString()
    }

    fun appLabels(): List<String> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { it.loadLabel(pm).toString() }
            .distinct()
            .sorted()
            .take(200)
    }

    // ---------- Actions ----------

    fun tapId(id: Int): Boolean {
        val n = nodes.getOrNull(id) ?: return false
        return clickNode(n)
    }

    fun tapText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val found = root.findAccessibilityNodeInfosByText(text)
        val n = found.firstOrNull { it.isVisibleToUser } ?: return false
        return clickNode(n)
    }

    fun tapXY(x: Int, y: Int): Boolean {
        val p = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        return gesture(p, 60)
    }

    fun scroll(direction: String): Boolean {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val p = Path()
        // "down" means: show content further down, so the finger swipes upward.
        when (direction) {
            "down" -> { p.moveTo(w / 2, h * 0.7f); p.lineTo(w / 2, h * 0.3f) }
            "up" -> { p.moveTo(w / 2, h * 0.3f); p.lineTo(w / 2, h * 0.7f) }
            "left" -> { p.moveTo(w * 0.8f, h / 2); p.lineTo(w * 0.2f, h / 2) }
            "right" -> { p.moveTo(w * 0.2f, h / 2); p.lineTo(w * 0.8f, h / 2) }
            else -> return false
        }
        return gesture(p, 350)
    }

    fun typeText(text: String): Boolean {
        val target = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: nodes.firstOrNull { it.isEditable }
            ?: return false
        if (target.isPassword) return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun pressEnter(): Boolean {
        if (Build.VERSION.SDK_INT < 30) return false
        val target = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        return target.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
    }

    fun openApp(name: String): Boolean {
        val pm = packageManager
        val q = name.lowercase().trim()
        if (q.isEmpty()) return false
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val best = pm.queryIntentActivities(intent, 0)
            .map { it to it.loadLabel(pm).toString().lowercase() }
            .filter { (_, label) -> label == q || label.contains(q) || q.contains(label) }
            .minByOrNull { it.second.length } ?: return false
        val launch = pm.getLaunchIntentForPackage(best.first.activityInfo.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launch)
        return true
    }

    fun openUrl(url: String): Boolean = try {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        false
    }

    fun call(number: String): Boolean {
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) return false
        return try {
            startActivity(
                Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number)))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Opens the SMS composer with the text filled in. Jarvis then taps "Send" after you confirm. */
    fun sms(number: String, body: String): Boolean = try {
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number)))
            .putExtra("sms_body", body)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        true
    } catch (e: Exception) {
        false
    }

    // ---------- Helpers ----------

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        while (c != null) {
            if (c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            c = c.parent
        }
        val r = Rect()
        n.getBoundsInScreen(r)
        return tapXY(r.centerX(), r.centerY())
    }

    private fun gesture(path: Path, durationMs: Long): Boolean {
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        val latch = CountDownLatch(1)
        var ok = false
        val dispatched = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                ok = true
                latch.countDown()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                latch.countDown()
            }
        }, null)
        if (!dispatched) return false
        latch.await(3, TimeUnit.SECONDS)
        return ok
    }
}
